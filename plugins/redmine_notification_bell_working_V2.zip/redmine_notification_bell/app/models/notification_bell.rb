class NotificationBell < ActiveRecord::Base
  belongs_to :user,    optional: true
  belongs_to :journal, optional: true
  belongs_to :issue,   optional: true

  scope :unread,   -> { where(read: false) }
  scope :for_user, ->(user) { where(user_id: user.id) }

  DEFAULT_MAX     = 20
  DEFAULT_PREVIEW = 100

  def self.max_per_user
    val = Setting.plugin_redmine_notification_bell['max_notifications'].to_i
    val.between?(1, 100) ? val : DEFAULT_MAX
  rescue
    DEFAULT_MAX
  end

  def self.preview_length
    val = Setting.plugin_redmine_notification_bell['preview_length'].to_i
    val.between?(20, 300) ? val : DEFAULT_PREVIEW
  rescue
    DEFAULT_PREVIEW
  end

  # Spawns a thread and returns immediately.
  # The journal object already has all attributes in memory — no re-fetch needed.
  def self.run_in_background(journal)
    Thread.new do
      begin
        ActiveRecord::Base.connection_pool.with_connection do
          create_for_mentions(journal)
        end
      rescue => e
        Rails.logger.error "[NotificationBell] background thread error: #{e.class}: #{e.message}\n#{e.backtrace.first(3).join("\n")}"
      end
    end
  end

  def self.create_for_mentions(journal)
    t0 = Time.now
    return unless journal.notes.present?
    return unless journal.journalized_type == 'Issue'

    issue = Issue.find_by(id: journal.journalized_id)
    return unless issue

    logins = journal.notes.scan(/(?<!\S)@([\w.\-]+)/).flatten.uniq
    Rails.logger.error "[NotificationBell] create_for_mentions start: journal=#{journal.id} logins=#{logins.inspect} elapsed=#{(Time.now - t0).round(2)}s"
    return if logins.empty?

    t1 = Time.now
    # Redmine anchors every journal sequentially (#1, #2, #3...) counting
    # ALL journals on the issue — not just those with notes.
    # A property-change journal with no note still occupies an anchor slot.
    all_journals = Journal
                     .where(journalized_type: 'Issue', journalized_id: issue.id)
                     .order(:created_on, :id)
                     .pluck(:id)
    note_index   = (all_journals.index(journal.id) || (all_journals.size - 1)) + 1
    Rails.logger.error "[NotificationBell] note_index query: #{(Time.now - t1).round(2)}s"

    author_name  = journal.user&.name.to_s
    note_preview = journal.notes.to_s.gsub(/\r?\n/, ' ').squish.truncate(preview_length)

    logins.each do |login|
      t2 = Time.now
      mentioned_user = User.active.find_by(login: login) ||
                       User.active.where('login LIKE ?', "#{login}@%").first
      Rails.logger.error "[NotificationBell] user lookup '#{login}': #{(Time.now - t2).round(2)}s result=#{mentioned_user&.login.inspect}"

      unless mentioned_user
        Rails.logger.error "[NotificationBell] No active user for login='#{login}'"
        next
      end

      next if mentioned_user.id == journal.user_id
      next if exists?(user_id: mentioned_user.id, journal_id: journal.id)

      notification = nil
      transaction(requires_new: true) do
        notification = create(
          user_id:       mentioned_user.id,
          journal_id:    journal.id,
          issue_id:      issue.id,
          note_index:    note_index,
          issue_subject: issue.subject.to_s.truncate(120),
          author_name:   author_name,
          note_preview:  note_preview,
          read:          false
        )
      end

      if notification&.persisted?
        Rails.logger.error "[NotificationBell] Created notification #{notification.id} for #{mentioned_user.login}"
        excess = where(user_id: mentioned_user.id)
                   .order(created_at: :desc, id: :desc)
                   .offset(max_per_user)
                   .pluck(:id)
        where(id: excess).delete_all if excess.any?
      else
        Rails.logger.error "[NotificationBell] create failed: #{notification&.errors&.full_messages}"
      end
    end

    Rails.logger.error "[NotificationBell] create_for_mentions done: total=#{(Time.now - t0).round(2)}s"
  rescue => e
    Rails.logger.error "[NotificationBell] create_for_mentions error: #{e.class}: #{e.message}\n#{e.backtrace.first(5).join("\n")}"
  end

  def issue_url
    "/issues/#{issue_id}#note-#{note_index}"
  end

  def as_json(*)
    {
      id:            id,
      read:          read,
      issue_id:      issue_id,
      issue_subject: issue_subject,
      author_name:   author_name,
      note_preview:  note_preview.to_s,
      note_index:    note_index,
      journal_id:    journal_id,
      created_at:    created_at.utc.iso8601,
      url:           issue_url
    }
  end
end
