module RedmineNotificationBell
  module JournalPatch
    def self.included(base)
      # after_commit fires after transaction commits — journal is in DB.
      # run_in_background spawns a Thread and returns instantly,
      # so this callback adds zero time to the HTTP request.
      base.after_commit :nb_detect_mentions, on: :create
    end

    private

    def nb_detect_mentions
      NotificationBell.run_in_background(self)
    rescue => e
      Rails.logger.error "[NotificationBell] nb_detect_mentions raised: #{e.class}: #{e.message}"
    end
  end
end

Rails.configuration.to_prepare do
  unless Journal.ancestors.include?(RedmineNotificationBell::JournalPatch)
    Journal.include(RedmineNotificationBell::JournalPatch)
    Rails.logger.error "[NotificationBell] JournalPatch applied — after_commit registered"
  end
end
