# Redmine Parent to Child Update - Hooks

module RedmineParentToChildUpdate
  class Hooks < Redmine::Hook::ViewListener
    include Rails.application.routes.url_helpers

    # ─── 1. NEW-ISSUE FORM ────────────────────────────────────────────────────
    # We only inject the shared CSS here.  The blocking form-level popup has been
    # removed because it was unreliable: the popup HTML was rendered based on the
    # tracker selected at page-load time, so it never appeared when the user
    # switched to a CR tracker after the form loaded.  All child-creation is now
    # handled by the show-page popup (hook #3 below).
    def view_issues_form_details_bottom(context = {})
      issue = context[:issue]
      return unless issue.parent_child_update_enabled?
      return if issue.parent_id.present?

      css = <<~CSS
        <style type='text/css'>
          .child-creation-modal { display:none; position:fixed; z-index:9999; left:0; top:0;
            width:100%; height:100%; background-color:rgba(0,0,0,0.5); font-family:Arial,sans-serif; }
          .child-creation-content { background:#fff; margin:6% auto; padding:24px;
            border:1px solid #888; width:540px; max-width:95%; border-radius:5px;
            box-shadow:0 4px 12px rgba(0,0,0,0.2); max-height:85vh; overflow-y:auto; }
          .child-creation-content h3 { margin-top:0; color:#333; }
          .child-creation-content label { font-weight:bold; }
          .child-creation-buttons { text-align:center; margin-top:20px; }
          .child-creation-buttons button { padding:10px 22px; margin:0 6px; font-size:14px;
            border-radius:3px; cursor:pointer; }
          .child-creation-buttons button.yes-btn { background:#4CAF50; color:#fff; border-color:#45a049; }
          .child-creation-buttons button.yes-btn:hover { background:#45a049; }
          .child-creation-buttons button.no-btn { background:#f44336; color:#fff; border-color:#da190b; }
          .child-creation-buttons button.no-btn:hover { background:#da190b; }
          .child-req-field { margin-bottom:12px; }
          .child-req-field label { display:block; font-size:13px; margin-bottom:4px; color:#444; }
          .child-req-field input, .child-req-field select {
            width:100%; padding:7px; font-size:13px; box-sizing:border-box; }
          .pcu-subtask-btn { display:inline-flex; align-items:center; gap:2px;
            background:none; color:#1976D2 !important; border:none; border-radius:0;
            padding:0; font-size:0.9em; cursor:pointer; text-decoration:none !important;
            margin-right:8px; vertical-align:middle; white-space:nowrap; font-weight:bold; }
          .pcu-subtask-btn:hover { color:#0d47a1 !important; text-decoration:underline !important; }
        </style>
      CSS
      css.html_safe
    end

    # ─── 2. AFTER NEW ISSUE SAVED ─────────────────────────────────────────────
    # Schedule the show-page popup only for CR-type issues.
    # We no longer process create_child / create_additional_tasks params here
    # because child creation now happens via AJAX from the show-page popup —
    # that path supports required custom fields and gives the user proper feedback.
    def controller_issues_new_after_save(context = {})
      issue      = context[:issue]
      controller = context[:controller]

      return unless issue.persisted?
      return unless issue.parent_child_update_enabled?
      return unless issue.tracker
      # Never auto-popup for issues that already have a parent (child issues)
      return if issue.parent_id.present?
      # Only schedule popup for hardcoded parent-tracker types
      return unless %w[change\ request user\ story].any? { |n| n.casecmp?(issue.tracker.name) }
      return unless controller && controller.session

      controller.session[:redmine_parent_to_child_show_prompt_for] = issue.id.to_i

      debug_logging = begin
        Setting.plugin_redmine_parent_to_child_update['enable_logging'] == '1'
      rescue
        false
      end
      Rails.logger.info("Parent to Child: Scheduled show-page popup for issue ##{issue.id}") if debug_logging
    end

    # ─── 3. ISSUE SHOW PAGE ───────────────────────────────────────────────────
    # Renders the child-creation modal on EVERY issue show page (hidden by default).
    # Opens two ways:
    #   a) Auto-open after CR creation (session key set in hook #2)
    #   b) User clicks "➕ Create Child" button injected next to Redmine's "+ ADD"
    def view_issues_show_details_bottom(context = {})
      issue      = context[:issue]
      controller = context[:controller]

      return unless issue.parent_child_update_enabled?
      return unless controller && controller.session
      return unless User.current.allowed_to?(:add_issues, issue.project)

      # ── Auto-open flag — consume session key BEFORE any early returns ────────
      # Must delete here so the key is never left dangling if we return early.
      scheduled_id = controller.session.delete(:redmine_parent_to_child_show_prompt_for)
      auto_open    = scheduled_id.to_i == issue.id.to_i

      # ── Filter tracker dropdown by per-parent-tracker plugin setting ─────────
      trackers_map    = Setting.plugin_redmine_parent_to_child_update['popup_child_trackers_by_parent'] || {}
      child_filter    = trackers_map[issue.tracker.id.to_s].to_s
                          .split(',').map(&:strip).reject(&:empty?)
      trackers = issue.available_child_trackers
      trackers = trackers.select { |t| child_filter.any? { |n| n.casecmp(t.name) == 0 } } if child_filter.any?
      return if trackers.empty? && !auto_open

      safe_subject      = ERB::Util.html_escape(issue.subject.to_s)
      safe_tracker_name = ERB::Util.html_escape(issue.tracker.name.to_s)

      output = +""

      # ── Read appearance settings ──────────────────────────────────────────────
      _pcu_cfg = Setting.plugin_redmine_parent_to_child_update rescue {}

      # Font size — clamp to 10–24 px
      _raw_fs  = _pcu_cfg['popup_font_size'].to_f
      _base_fs = _raw_fs.between?(10, 24) ? _raw_fs : 12.5

      # Footer gradient
      _raw_fc   = _pcu_cfg['popup_footer_color'].to_s
      _fc_parts = _raw_fc.split(',').map(&:strip).select { |c| c.match?(/\A#[0-9a-fA-F]{3,6}\z/) }
      _fc1 = _fc_parts[0].presence || '#f8fafc'
      _fc2 = _fc_parts[1].presence || '#eff6ff'

      # ── Modal CSS ─────────────────────────────────────────────────────────────
      output << "<style type='text/css'>"
      # CSS custom properties — all popup sizes derive from --pcu-fs
      output << "#pcu-child-modal{--pcu-fs:#{_base_fs}px;"
      output << "  --pcu-fs-sm:calc(var(--pcu-fs) * 0.85);"
      output << "  --pcu-fs-lg:calc(var(--pcu-fs) * 1.1);"
      output << "  --pcu-fs-h3:calc(var(--pcu-fs) * 1.15);}"
      # Google Inter font for modern look
      output << "@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');"
      # Backdrop
      output << "#pcu-child-modal{"
      output << "  display:none;position:fixed;z-index:99999;left:0;top:0;"
      output << "  width:100%;height:100%;"
      output << "  background:rgba(15,23,42,0.6);backdrop-filter:blur(4px);"
      output << "  font-family:'Inter',system-ui,-apple-system,sans-serif;overflow:visible;"
      output << "  animation:pcuFadeIn 0.18s ease;}"
      output << "@keyframes pcuFadeIn{from{opacity:0}to{opacity:1}}"
      # Modal box
      output << "#pcu-child-modal .pcu-modal-box{"
      output << "  background:#fff;margin:1.5% auto;padding:0;"
      output << "  border-radius:12px;width:1380px;max-width:98%;"
      output << "  box-shadow:0 20px 60px rgba(0,0,0,0.18),0 4px 16px rgba(0,0,0,0.1);"
      output << "  max-height:96vh;overflow:visible;border:1px solid rgba(0,0,0,0.06);"
      output << "  animation:pcuSlideUp 0.2s ease;}"
      # Scroll the modal body instead so the box itself stays overflow:visible,
      # allowing jstoolbar table/colour pickers to escape the modal boundary.
      output << "#pcu-child-modal .pcu-modal-body{max-height:calc(96vh - 120px);overflow-y:auto;}"
      output << "@keyframes pcuSlideUp{from{transform:translateY(16px);opacity:0.6}to{transform:translateY(0);opacity:1}}"
      # Header
      raw_hdr = (Setting.plugin_redmine_parent_to_child_update['popup_header_color'] rescue nil).to_s
      hdr_parts  = raw_hdr.split(',').map(&:strip).select { |c| c.match?(/\A#[0-9a-fA-F]{3,6}\z/) }
      hdr_color1 = hdr_parts[0].presence || '#eff6ff'
      hdr_color2 = hdr_parts[1].presence || '#dbeafe'
      output << ".pcu-modal-header{"
      output << "  display:flex;align-items:center;justify-content:space-between;"
      output << "  padding:14px 24px;border-bottom:2px solid #e2e8f0;"
      output << "  background:linear-gradient(135deg,#{hdr_color1} 0%,#{hdr_color2} 100%);"
      output << "  border-radius:12px 12px 0 0;}"
      output << ".pcu-modal-header h3{margin:0;color:#1e3a8a;font-size:var(--pcu-fs-h3);font-weight:700;"
      output << "  letter-spacing:0.01em;}"
      output << ".pcu-modal-close-x{background:rgba(30,58,138,0.08);border:1px solid #bfdbfe;"
      output << "  font-size:15px;cursor:pointer;color:#1e40af;line-height:1;padding:4px 9px;"
      output << "  border-radius:6px;font-weight:700;transition:all 0.15s;}"
      output << ".pcu-modal-close-x:hover{background:#dbeafe;color:#1e3a8a;border-color:#93c5fd;}"
      # Body
      output << ".pcu-modal-body{padding:20px 24px 12px;}"
      # Description banner
      output << "#pcu-child-modal .pcu-desc{"
      output << "  color:#475569;font-size:var(--pcu-fs);margin-bottom:14px;padding:10px 14px;"
      output << "  background:#f8fafc;border-left:3px solid #3b82f6;border-radius:0 6px 6px 0;"
      output << "  line-height:1.5;}"
      output << "#pcu-child-modal .pcu-desc strong{color:#1e40af;}"
      # Top row: tracker + subject
      output << ".pcu-top-row{display:grid;grid-template-columns:1fr 2fr;gap:14px;margin-bottom:14px;"
      output << "  padding-bottom:14px;border-bottom:1px solid #f1f5f9;}"
      # Fields grid
      output << "#pcu-required-fields{display:grid;grid-template-columns:repeat(4,1fr);gap:12px 16px;align-items:start;}"
      output << "#pcu-required-fields .pcu-field-full{grid-column:1/-1;}"
      # Section label style
      output << "#pcu-child-modal .pcu-section-label{"
      output << "  font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;"
      output << "  color:#94a3b8;margin:12px 0 6px;grid-column:1/-1;}"
      # Labels
      output << "#pcu-child-modal label,#pcu-child-modal .child-req-field label{"
      output << "  font-weight:500;font-size:var(--pcu-fs-sm);display:block;margin-bottom:4px;"
      output << "  color:#374151;letter-spacing:0.01em;}"
      # All inputs / selects / textareas
      output << "#pcu-child-modal select,"
      output << "#pcu-child-modal input[type=text],"
      output << "#pcu-child-modal input[type=number],"
      output << "#pcu-child-modal input[type=date]{"
      output << "  width:100%;padding:7px 10px;font-size:var(--pcu-fs);line-height:1.4;"
      output << "  box-sizing:border-box;height:auto;min-height:34px;"
      output << "  border:1.5px solid #e2e8f0;border-radius:7px;margin-top:0;"
      output << "  background:#fff;color:#1e293b;transition:border-color 0.15s,box-shadow 0.15s;"
      output << "  font-family:inherit;vertical-align:middle;overflow:visible;"
      output << "  white-space:nowrap;text-overflow:ellipsis;}"
      output << "#pcu-child-modal select{"
      output << "  padding-right:24px;appearance:auto;-webkit-appearance:auto;}"
      output << "#pcu-child-modal select:focus,"
      output << "#pcu-child-modal input[type=text]:focus,"
      output << "#pcu-child-modal input[type=number]:focus,"
      output << "#pcu-child-modal input[type=date]:focus{"
      output << "  outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,0.12);}"
      output << "#pcu-child-modal select:hover:not(:disabled),"
      output << "#pcu-child-modal input:hover:not(:disabled){"
      output << "  border-color:#94a3b8;}"
      # Readonly / disabled fields — lighter tint so text stays readable
      output << "#pcu-child-modal input:disabled,#pcu-child-modal select:disabled,#pcu-child-modal textarea:disabled{"
      output << "  background:#f1f5f9 !important;color:#64748b !important;"
      output << "  border-color:#e2e8f0 !important;cursor:not-allowed !important;}"
      # Field blocks
      output << ".pcu-field-block,.child-req-field{margin-bottom:0;}"
      # Textarea
      output << ".child-req-field textarea{"
      output << "  width:100%;padding:8px 10px;font-size:var(--pcu-fs);box-sizing:border-box;"
      output << "  border:1.5px solid #e2e8f0;border-radius:7px;height:auto;min-height:80px;"
      output << "  resize:vertical;font-family:inherit;transition:border-color 0.15s,box-shadow 0.15s;}"
      output << ".child-req-field textarea:focus{"
      output << "  outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,0.12);}"
      # Badges
      output << ".pcu-badge{"
      output << "  display:inline-block;font-size:9px;font-weight:700;letter-spacing:0.04em;"
      output << "  border-radius:4px;padding:1px 5px;margin-left:5px;vertical-align:middle;"
      output << "  text-transform:uppercase;}"
      output << ".pcu-badge-std{background:#dbeafe;color:#1d4ed8;}"
      output << ".pcu-badge-req{background:#fee2e2;color:#b91c1c;}"
      output << ".pcu-badge-ro{background:#f1f5f9;color:#64748b;border:1px solid #cbd5e1;}"
      # jsToolBar — allow table picker and other dropdowns to overflow the modal
      output << "#pcu-child-modal .jstBlock{width:100%;box-sizing:border-box;overflow:visible;}"
      output << "#pcu-child-modal .jstEditor{width:100% !important;overflow:visible;}"
      output << "#pcu-child-modal .jstEditor textarea{height:80px;width:100% !important;box-sizing:border-box;"
      output << "  border:1.5px solid #e2e8f0;border-radius:7px;}"
      # jstoolbar toolbar row must allow its pickers to overflow
      output << "#pcu-child-modal .jstElements{overflow:visible;position:relative;}"
      # Table picker and colour/link pickers rendered as absolute children of toolbar buttons
      output << "#pcu-child-modal .jstb_table_picker,"
      output << "#pcu-child-modal div[id$='_picker'],"
      output << "#pcu-child-modal .jstb_table>div,"
      output << "#pcu-child-modal .jstb_color>div{"
      output << "  z-index:2147483647 !important;position:absolute;}"
      # Scrollable required-fields area stays visible so pickers escape
      output << "#pcu-required-fields{overflow:visible;}"
      # Spin-button removal
      output << "#pcu-child-modal input[type=number]{-moz-appearance:textfield;appearance:textfield;}"
      output << "#pcu-child-modal input[type=number]::-webkit-outer-spin-button,"
      output << "#pcu-child-modal input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0;}"
      # Status message
      output << "#pcu-status-msg{display:none;margin:10px 0 0;padding:10px 14px;border-radius:8px;"
      output << "  font-size:var(--pcu-fs);font-weight:500;border:1px solid transparent;}"
      # Files row
      output << ".pcu-files-row{margin-top:14px;padding:12px 0 0;border-top:1px solid #f1f5f9;}"
      output << ".pcu-files-row label{color:#374151;font-size:var(--pcu-fs-sm);font-weight:500;margin-bottom:6px;display:block;}"
      output << ".pcu-files-row input[type=file]{font-size:var(--pcu-fs-sm);color:#475569;}"
      # Footer — color from settings
      output << ".pcu-modal-footer{"
      output << "  padding:14px 24px;border-top:2px solid #e2e8f0;"
      output << "  display:flex;gap:8px;flex-wrap:wrap;align-items:center;"
      output << "  background:linear-gradient(135deg,#{_fc1} 0%,#{_fc2} 100%);border-radius:0 0 12px 12px;}"
      # Buttons — base
      output << ".pcu-btn{"
      output << "  padding:8px 18px;font-size:var(--pcu-fs);border-radius:8px;cursor:pointer;border:none;"
      output << "  font-weight:600;font-family:inherit;letter-spacing:0.01em;"
      output << "  transition:all 0.15s;display:inline-flex;align-items:center;gap:6px;}"
      output << ".pcu-btn:active{transform:scale(0.97);}"
      # Save (primary green)
      output << ".pcu-btn-save{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff;"
      output << "  box-shadow:0 2px 8px rgba(34,197,94,0.3);}"
      output << ".pcu-btn-save:hover{background:linear-gradient(135deg,#15803d,#16a34a);"
      output << "  box-shadow:0 4px 12px rgba(34,197,94,0.4);}"
      # Save & Create Child (blue)
      output << ".pcu-btn-save-child{background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;"
      output << "  box-shadow:0 2px 8px rgba(59,130,246,0.3);}"
      output << ".pcu-btn-save-child:hover{background:linear-gradient(135deg,#1e40af,#1d4ed8);"
      output << "  box-shadow:0 4px 12px rgba(59,130,246,0.4);}"
      # Clear (amber outline)
      output << ".pcu-btn-clear{background:#fff;color:#d97706;border:1.5px solid #fbbf24;"
      output << "  box-shadow:0 1px 4px rgba(217,119,6,0.15);}"
      output << ".pcu-btn-clear:hover{background:#fffbeb;border-color:#f59e0b;}"
      # Close (neutral)
      output << ".pcu-btn-close{background:#fff;color:#475569;border:1.5px solid #e2e8f0;"
      output << "  box-shadow:0 1px 4px rgba(0,0,0,0.06);}"
      output << ".pcu-btn-close:hover{background:#f1f5f9;border-color:#cbd5e1;}"
      output << ".pcu-btn:disabled{opacity:0.55;cursor:not-allowed;transform:none;}"
      # Subtask inject button
      output << ".pcu-subtask-btn{display:inline-flex;align-items:center;gap:4px;"
      output << "  background:none;color:#2563eb !important;border:none;"
      output << "  padding:0;font-size:0.85em;cursor:pointer;text-decoration:none !important;"
      output << "  margin-right:6px;vertical-align:middle;white-space:nowrap;font-weight:600;"
      output << "  letter-spacing:0.02em;}"
      output << ".pcu-subtask-btn:hover{color:#1d4ed8 !important;text-decoration:underline !important;}"
      output << "</style>"

      # Trackers that have children configured → show "Save & Create Child Tracker" button
      trackers_with_children = (Setting.plugin_redmine_parent_to_child_update['popup_child_trackers_by_parent'] || {})
                                 .select { |_, v| v.to_s.strip.present? }.keys.map(&:to_s)
      # Hardcoded parent tracker names — these always get "Save & Create Child Tracker" button
      popup_parent_names_set = %w[change\ request user\ story]
      # Current issue is itself a parent tracker → always show chain buttons
      current_is_parent = popup_parent_names_set.any? { |n| n.casecmp?(issue.tracker.name) }

      # JS map: tracker_id => { hasChildren, isTerminal }
      tracker_has_children_js = trackers.map { |t|
        is_terminal = !popup_parent_names_set.include?(t.name.downcase)
        "\"#{t.id}\":{c:#{trackers_with_children.include?(t.id.to_s)},term:#{is_terminal}}"
      }.join(',')
      # JS map: tracker_id => tracker_name (for display)
      tracker_names_js = trackers.map { |t|
        "\"#{t.id}\":#{t.name.to_json}"
      }.join(',')

      # ── Modal HTML (always rendered, hidden by default) ────────────────────
      output << "<div id='pcu-child-modal'>"
      output << "  <div class='pcu-modal-box'>"

      # Header with X close button
      output << "  <div class='pcu-modal-header'>"
      output << "    <h3>Create Child Tracker</h3>"
      output << "    <button type='button' class='pcu-modal-close-x' onclick='pcuCloseModal()' title='Close'>&#10005;</button>"
      output << "  </div>"

      # Body
      output << "  <div class='pcu-modal-body'>"
      output << "    <p class='pcu-desc'>Create a child tracker under <strong>#{safe_tracker_name} ##{issue.id} &ndash; #{safe_subject}</strong>.</p>"

      # Tracker type + Subject in a 2-column top row
      output << "    <div class='pcu-top-row'>"
      output << "      <div class='pcu-field-block'>"
      output << "        <label for='pcu-tracker-select'>Child tracker type <span style='color:red'>*</span></label>"
      output << "        <select id='pcu-tracker-select' onchange='pcuOnTrackerChange(#{issue.id})'>"
      trackers.each_with_index do |t, i|
        output << "          <option value='#{t.id}'#{i == 0 ? ' selected' : ''}>#{ERB::Util.html_escape(t.name)}</option>"
      end
      output << "        </select>"
      output << "      </div>"
      output << "      <div class='pcu-field-block'>"
      output << "        <label for='pcu-subject'>Tracker subject <span style='color:red'>*</span></label>"
      output << "        <input type='text' id='pcu-subject' value='#{safe_subject}' placeholder='Enter tracker subject'>"
      output << "      </div>"
      output << "    </div>"

      # Dynamic fields — rendered in 3-column grid by CSS; text/textarea fields span full width via JS
      output << "    <div id='pcu-required-fields'></div>"

      # File upload — full-width row below the fields grid
      max_size_kb = Setting.attachment_max_size.to_i rescue 5120
      max_size_mb = (max_size_kb / 1024.0).round(1)
      output << "    <div class='pcu-files-row'>"
      output << "      <label for='pcu-files' style='font-size:12px;font-weight:bold;margin-bottom:3px;display:block;'>Files</label>"
      output << "      <div style='display:flex;align-items:center;gap:12px;'>"
      output << "        <input type='file' id='pcu-files' multiple style='font-size:12px;'>"
      output << "        <span style='color:#888;font-size:11px;'>Max #{max_size_mb} MB per file</span>"
      output << "      </div>"
      output << "    </div>"

      output << "    <div id='pcu-status-msg'></div>"
      output << "  </div>"

      # Footer buttons
      output << "  <div class='pcu-modal-footer'>"
      output << "    <button type='button' class='pcu-btn pcu-btn-save' id='pcu-btn-save'"
      output << "            onclick='pcuSubmit(#{issue.id},false)'>Save Tracker</button>"
      output << "    <button type='button' class='pcu-btn pcu-btn-save-child' id='pcu-btn-save-child'"
      output << "            onclick='pcuSubmit(#{issue.id},true)' style='display:none'>Save &amp; Create Child Tracker</button>"
      output << "    <button type='button' class='pcu-btn pcu-btn-clear'"
      output << "            onclick='pcuClearFields()'>Clear</button>"
      output << "    <button type='button' class='pcu-btn pcu-btn-close'"
      output << "            onclick='pcuCloseModal()'>Close</button>"
      output << "  </div>"
      output << "  </div>"
      output << "</div>"

      # ── JavaScript ────────────────────────────────────────────────────────
      output << "<script type='text/javascript'>"

      output << "var pcuTrackerInfo={#{tracker_has_children_js}};"
      output << "var pcuTrackerNames={#{tracker_names_js}};"
      # Legacy alias — keeps any other code that references this working
      output << "var pcuTrackerHasChildren={};"
      output << "Object.keys(pcuTrackerInfo).forEach(function(k){pcuTrackerHasChildren[k]=pcuTrackerInfo[k].c;});"

      output << "function pcuCsrfToken(){"
      output << "  var m=document.querySelector('meta[name=csrf-token]');"
      output << "  if(m) return m.getAttribute('content');"
      output << "  var i=document.querySelector('input[name=authenticity_token]');"
      output << "  return i?i.value:null;"
      output << "}"

      # Close and fully reset the modal
      output << "function pcuCloseModal(){"
      output << "  document.getElementById('pcu-child-modal').style.display='none';"
      output << "  document.getElementById('pcu-required-fields').innerHTML='';"
      output << "  var msg=document.getElementById('pcu-status-msg');"
      output << "  if(msg){msg.style.display='none';msg.textContent='';}"
      output << "  document.getElementById('pcu-btn-save').disabled=false;"
      output << "  var sc=document.getElementById('pcu-btn-save-child');"
      output << "  if(sc) sc.disabled=false;"
      output << "}"

      # Clear all editable fields in the popup (reset to blank / first option)
      output << "function pcuClearFields(){"
      output << "  document.getElementById('pcu-subject').value='';"
      output << "  document.querySelectorAll('#pcu-required-fields .pcu-req-cf').forEach(function(inp){"
      output << "    if(inp.tagName==='SELECT') inp.selectedIndex=0;"
      output << "    else inp.value='';"
      output << "  });"
      output << "  var fi=document.getElementById('pcu-files');"
      output << "  if(fi) fi.value='';"
      output << "  var msg=document.getElementById('pcu-status-msg');"
      output << "  if(msg){msg.style.display='none';msg.textContent='';}"
      output << "}"

      # Update buttons and load fields when tracker changes
      output << "function pcuOnTrackerChange(parentId){"
      output << "  var tid=document.getElementById('pcu-tracker-select').value;"
      output << "  var info=pcuTrackerInfo[tid]||{c:false,term:true};"
      output << "  var sc=document.getElementById('pcu-btn-save-child');"
      output << "  var saveBtn=document.getElementById('pcu-btn-save');"
      output << "  var closeBtn=document.getElementById('pcu-btn-close');"
      # Show "Save & Create Child" only when current issue is a parent tracker AND
      # the selected child tracker is also a chain parent (not terminal, e.g. User Story).
      # When Task is selected (terminal), hide the button.
      if current_is_parent
        output << "  var showChain=!info.term;"
        output << "  if(sc) sc.style.display=(showChain?'':'none');"
        output << "  if(saveBtn) saveBtn.textContent='Save Tracker';"
        output << "  if(closeBtn) closeBtn.textContent=(showChain?'Close':'Cancel');"
      else
        output << "  if(sc) sc.style.display='none';"
        output << "  if(saveBtn) saveBtn.textContent='Save';"
        output << "  if(closeBtn) closeBtn.textContent='Cancel';"
      end
      output << "  pcuLoadRequiredFields(parentId);"
      output << "}"

      # Save current field values keyed by field id (std_key or cf_id or ext_key).
      output << "function pcuSaveFieldValues(){"
      output << "  var saved={};"
      output << "  document.querySelectorAll('#pcu-required-fields .pcu-req-cf').forEach(function(inp){"
      output << "    var key=inp.dataset.stdKey||('cf_'+inp.dataset.cfId)||('ext_'+inp.dataset.extKey)||'';"
      output << "    if(!key) return;"
      output << "    if(inp.dataset.fieldFormat==='multiselect'&&inp._msWrap){"
      output << "      saved[key]=Object.assign({},inp._msWrap._selected);"
      output << "    } else { saved[key]=inp.value; }"
      output << "  });"
      output << "  return saved;"
      output << "}"
      output << "function pcuRestoreFieldValues(saved){"
      output << "  if(!saved) return;"
      output << "  document.querySelectorAll('#pcu-required-fields .pcu-req-cf').forEach(function(inp){"
      output << "    var key=inp.dataset.stdKey||('cf_'+inp.dataset.cfId)||('ext_'+inp.dataset.extKey)||'';"
      output << "    if(!key||!(key in saved)) return;"
      output << "    if(inp.dataset.fieldFormat==='multiselect'&&inp._msWrap){"
      output << "      inp._msWrap._selected=saved[key]||{};"
      output << "      if(typeof msPills==='function') msPills();"
      output << "    } else if(saved[key]!==undefined&&saved[key]!=='') inp.value=saved[key];"
      output << "  });"
      output << "}"
      # Load admin-configured popup fields for selected tracker + current status
      output << "function pcuLoadRequiredFields(parentId,statusId,savedValues){"
      output << "  var tid=document.getElementById('pcu-tracker-select').value;"
      output << "  var box=document.getElementById('pcu-required-fields');"
      output << "  if(!tid) return;"
      output << "  var url='/redmine_parent_to_child_update/child_issues/required_fields/'+parentId+'?tracker_id='+tid;"
      output << "  if(statusId) url+='&status_id='+statusId;"
      output << "  box.innerHTML='';"
      output << "  fetch(url,{"
      output << "    headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'},"
      output << "    credentials:'same-origin'"
      output << "  }).then(function(r){"
      output << "    if(!r.ok) return r.json().then(function(j){throw new Error(j.error||('HTTP '+r.status));});"
      output << "    return r.json();"
      output << "  })"
      output << "  .then(function(json){"
      output << "    if(json.error){ pcuShowStatus('Could not load fields: '+json.error,'#fef2f2','#991b1b'); return; }"
      output << "    if(!json.fields||json.fields.length===0) return;"
      output << "    json.fields.forEach(function(cf){"
      # text/textarea fields span all 3 columns; everything else fits in one column
      output << "      var isWide=(cf.field_format==='text');"
      output << "      var w=document.createElement('div');"
      output << "      w.className='child-req-field'+(isWide?' pcu-field-full':'');"
      output << "      var lb=document.createElement('label');"
      output << "      var badge=cf.is_readonly"
      output << "        ? '<span class=\"pcu-badge pcu-badge-ro\">read-only</span>'"
      output << "        : (cf.is_required"
      output << "          ? '<span class=\"pcu-badge pcu-badge-req\">required</span>'"
      output << "          : (cf.is_standard"
      output << "            ? '<span class=\"pcu-badge pcu-badge-std\">std</span>'"
      output << "            : ''));"
      output << "      lb.innerHTML=cf.name+badge; w.appendChild(lb);"
      output << "      var initVal=(cf.value&&cf.value.trim()!=='')?cf.value:(cf.default_value||'');"
      output << "      var inp;"
      # 'select' = standard fields with dynamic options (user, priority, category, version)
      output << "      if(cf.field_format==='select'&&cf.possible_values.length>0){"
      output << "        inp=document.createElement('select');"
      output << "        var bk=document.createElement('option'); bk.value=''; bk.textContent='-- Select --'; inp.appendChild(bk);"
      output << "        cf.possible_values.forEach(function(pv){"
      output << "          var o=document.createElement('option');"
      output << "          o.value=pv.value||pv; o.textContent=pv.label||pv;"
      output << "          if(o.value===initVal) o.selected=true; inp.appendChild(o);"
      output << "        });"
      # 'list' = custom fields with static options
      output << "      } else if(cf.field_format==='list'&&cf.possible_values.length>0){"
      output << "        inp=document.createElement('select');"
      output << "        var bk=document.createElement('option'); bk.value=''; bk.textContent='-- Select --'; inp.appendChild(bk);"
      output << "        cf.possible_values.forEach(function(v){"
      output << "          var o=document.createElement('option'); o.value=v; o.textContent=v;"
      output << "          if(v===initVal) o.selected=true; inp.appendChild(o);"
      output << "        });"
      output << "      } else if(cf.field_format==='bool'){"
      output << "        inp=document.createElement('select');"
      output << "        [['','-- Select --'],['0','No'],['1','Yes']].forEach(function(p){"
      output << "          var o=document.createElement('option'); o.value=p[0]; o.textContent=p[1];"
      output << "          if(p[0]===initVal) o.selected=true; inp.appendChild(o);"
      output << "        });"
      output << "      } else if(cf.field_format==='date'){"
      output << "        inp=document.createElement('input'); inp.type='date';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      } else if(cf.field_format==='float'){"
      output << "        inp=document.createElement('input'); inp.type='number'; inp.step='0.01';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      } else if(cf.field_format==='int'){"
      output << "        inp=document.createElement('input'); inp.type='number';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      } else if(cf.is_standard&&cf.std_key==='parent_issue_id'){"
      output << "        inp=document.createElement('input'); inp.type='text';"
      output << "        inp.readOnly=true;"
      output << "        inp.style.cssText='width:100%;padding:7px 10px;font-size:var(--pcu-fs);box-sizing:border-box;height:auto;min-height:34px;background:#f8fafc;color:#475569;border:1.5px solid #e2e8f0;border-radius:7px;cursor:default;';"
      output << "        if(initVal) inp.value='#'+initVal;"
      output << "      } else if(cf.field_format==='text'){"
      output << "        inp=document.createElement('textarea'); inp.rows=3;"
      output << "        inp.style.cssText='width:100%;padding:5px 8px;font-size:12px;box-sizing:border-box;min-height:80px;resize:vertical;';"
      output << "        if(cf.is_standard&&cf.std_key==='description') inp.id='pcu-desc-textarea';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      } else if(cf.field_format==='color'){"
      output << "        inp=document.createElement('input'); inp.type='color';"
      output << "        inp.style.cssText='width:60px;height:32px;padding:2px;border:1.5px solid #e2e8f0;border-radius:7px;cursor:pointer;';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      } else if(cf.field_format==='multiselect'&&cf.possible_values.length>0){"
      # Build a custom searchable multi-select widget; inp is a hidden sentinel div
      output << "        var msWrap=document.createElement('div');"
      output << "        msWrap.style.cssText='position:relative;width:100%;box-sizing:border-box;';"
      # Pill container + search input row
      output << "        var msBox=document.createElement('div');"
      output << "        msBox.style.cssText='display:flex;flex-wrap:wrap;gap:4px;align-items:center;min-height:36px;padding:4px 8px;border:1.5px solid #e2e8f0;border-radius:7px;cursor:text;background:#fff;box-sizing:border-box;width:100%;';"
      output << "        var msSearch=document.createElement('input'); msSearch.type='text';"
      output << "        msSearch.placeholder='Search...';"
      output << "        msSearch.style.cssText='border:none;outline:none;flex:1;min-width:80px;font-size:var(--pcu-fs);background:transparent;padding:2px 0;';"
      output << "        msBox.appendChild(msSearch);"
      # Dropdown list
      output << "        var msDrop=document.createElement('div');"
      output << "        msDrop.style.cssText='display:none;position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;border:1.5px solid #bfdbfe;border-radius:7px;background:#fff;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.13);margin-top:2px;';"
      # Store selected values in a JS object on the wrapper
      output << "        msWrap._selected={};"
      output << "        function msRender(){"
      output << "          var q=msSearch.value.toLowerCase();"
      output << "          msDrop.innerHTML='';"
      output << "          var shown=0;"
      output << "          cf.possible_values.forEach(function(pv){"
      output << "            var val=pv.value||pv; var lbl=pv.label||pv;"
      output << "            if(q&&lbl.toLowerCase().indexOf(q)<0) return;"
      output << "            var li=document.createElement('div');"
      output << "            var isSel=!!msWrap._selected[val];"
      output << "            li.style.cssText='padding:7px 12px;cursor:pointer;font-size:var(--pcu-fs);display:flex;align-items:center;gap:8px;'+(isSel?'background:#eff6ff;color:#1d4ed8;':'');"
      output << "            var chk=document.createElement('span'); chk.textContent=isSel?'✓':''; chk.style.cssText='width:14px;display:inline-block;font-size:12px;color:#1d4ed8;';"
      output << "            li.appendChild(chk); li.appendChild(document.createTextNode(lbl));"
      output << "            li.addEventListener('mousedown',function(e){ e.preventDefault();"
      output << "              if(msWrap._selected[val]){ delete msWrap._selected[val]; } else { msWrap._selected[val]=lbl; }"
      output << "              msPills(); msRender();"
      output << "            });"
      output << "            msDrop.appendChild(li); shown++;"
      output << "          });"
      output << "          if(!shown){ var ni=document.createElement('div'); ni.textContent='No results'; ni.style.cssText='padding:8px 12px;color:#999;font-size:var(--pcu-fs);'; msDrop.appendChild(ni); }"
      output << "        }"
      output << "        function msPills(){"
      output << "          Array.from(msBox.querySelectorAll('.ms-pill')).forEach(function(p){p.remove();});"
      output << "          Object.keys(msWrap._selected).forEach(function(val){"
      output << "            var pill=document.createElement('span'); pill.className='ms-pill';"
      output << "            pill.style.cssText='display:inline-flex;align-items:center;gap:4px;background:#dbeafe;color:#1d4ed8;border-radius:12px;padding:2px 8px;font-size:var(--pcu-fs-sm);white-space:nowrap;';"
      output << "            pill.textContent=msWrap._selected[val];"
      output << "            var x=document.createElement('span'); x.textContent='×'; x.style.cssText='cursor:pointer;font-size:14px;line-height:1;margin-left:2px;color:#1d4ed8;';"
      output << "            x.addEventListener('click',function(){ delete msWrap._selected[val]; msPills(); });"
      output << "            pill.appendChild(x); msBox.insertBefore(pill,msSearch);"
      output << "          });"
      output << "        }"
      output << "        msSearch.addEventListener('input',function(){ msDrop.style.display='block'; msRender(); });"
      output << "        msSearch.addEventListener('focus',function(){ msDrop.style.display='block'; msRender(); });"
      output << "        msSearch.addEventListener('blur',function(){ setTimeout(function(){msDrop.style.display='none';},150); });"
      output << "        msBox.addEventListener('click',function(){ msSearch.focus(); });"
      output << "        msWrap.appendChild(msBox); msWrap.appendChild(msDrop);"
      # inp is a sentinel div that carries dataset attributes and _selected reference
      output << "        inp=document.createElement('div');"
      output << "        inp.style.display='none';"
      output << "        inp._msWrap=msWrap;"
      output << "        w.appendChild(msWrap);"
      output << "      } else {"
      output << "        inp=document.createElement('input'); inp.type='text';"
      output << "        if(initVal) inp.value=initVal;"
      output << "      }"
      # Tag inputs: std_key, ext_key, or cf_id so pcuSubmit knows how to post them
      output << "      if(cf.is_standard){ inp.dataset.stdKey=cf.std_key; }"
      output << "      else if(cf.is_extra){ inp.dataset.extKey=cf.ext_key; }"
      output << "      else { inp.dataset.cfId=cf.id; }"
      output << "      inp.dataset.fieldName=cf.name;"
      output << "      inp.dataset.fieldFormat=cf.field_format||'';"
      output << "      inp.dataset.required=cf.is_required?'1':'0';"
      output << "      if(cf.is_readonly){"
      output << "        inp.disabled=true;"
      output << "        inp.style.background='#f5f5f5';inp.style.color='#888';inp.style.cursor='not-allowed';"
      output << "        inp.title='Read-only (workflow permission)';"
      output << "      }"
      output << "      if(inp.type==='number'){inp.addEventListener('wheel',function(e){e.preventDefault();},{passive:false});}"
      output << "      inp.className='pcu-req-cf'; w.appendChild(inp); box.appendChild(w);"
      output << "    });"
      # Initialise Redmine's wiki toolbar on the description textarea if available.
      # jsToolBar is already loaded on issue pages; we call it after a short delay so
      # the textarea is fully in the DOM before the toolbar wraps it.
      _preview_url = begin
        preview_issue_path(project_id: issue.project.identifier)
      rescue
        begin
          Rails.application.routes.url_helpers.preview_issue_path(
            project_id: issue.project.identifier
          )
        rescue
          _url_root = (Redmine::Utils.relative_url_root.to_s rescue '').chomp('/')
          _proj_id  = ERB::Util.url_encode(issue.project.identifier.to_s)
          "#{_url_root}/preview/issue?project_id=#{_proj_id}"
        end
      end
      output << "    setTimeout(function(){"
      output << "      var descTa=document.getElementById('pcu-desc-textarea');"
      output << "      if(!descTa||typeof jsToolBar==='undefined'||descTa.dataset.tbInit) return;"
      output << "      descTa.dataset.tbInit='1';"
      output << "      try{"
      output << "        var tb=new jsToolBar(descTa);"
      output << "        if(tb.setHelpLink) tb.setHelpLink('');"
      # Leave previewPath unset so jstoolbar does NOT fire its own XHR (which would race and blank the panel)
      output << "        tb.draw();"
      # MutationObserver watches only style attribute changes (NOT childList) so our own
      # innerHTML writes don't re-trigger the observer and cause an infinite fetch loop.
      output << "        setTimeout(function(){"
      output << "          var jstBlock=descTa.parentNode;"
      output << "          while(jstBlock&&!jstBlock.classList.contains('jstBlock')) jstBlock=jstBlock.parentNode;"
      output << "          if(!jstBlock) return;"
      output << "          var previewBox=jstBlock.querySelector('.jstPreview,.wiki-preview');"
      output << "          var _prevFetching=false;"
      output << "          new MutationObserver(function(mutations){"
      output << "            mutations.forEach(function(m){"
      output << "              var t=m.target;"
      # Detect jstPreview becoming visible (style attribute on the previewBox element itself)
      output << "              if(previewBox&&t===previewBox&&m.attributeName==='style'){"
      output << "                if(previewBox.style.display==='none') return;" # hidden — ignore
      output << "                if(_prevFetching) return; _prevFetching=true;"
      output << "                previewBox.innerHTML='<em style=\"color:#64748b\">Loading preview…</em>';"
      output << "                var text=descTa.value;"
      output << "                var token=(document.querySelector('meta[name=csrf-token]')||{}).content||'';"
      output << "                fetch('#{_preview_url}',{"
      output << "                  method:'POST',"
      output << "                  headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},"
      output << "                  credentials:'same-origin',"
      output << "                  body:'text='+encodeURIComponent(text)+'&authenticity_token='+encodeURIComponent(token)+'&project_id=#{ERB::Util.url_encode(issue.project.identifier.to_s)}'"
      output << "                }).then(function(r){return r.text();})"
      output << "                  .then(function(html){"
      # Wrap in .wiki so Redmine's wiki stylesheet (headings, bold, lists, code) applies
      output << "                    previewBox.innerHTML='<div class=\"wiki\">'+( html||'<em style=\"color:#94a3b8\">(empty)</em>' )+'</div>';"
      output << "                    _prevFetching=false;"
      output << "                  })"
      output << "                  .catch(function(e){previewBox.innerHTML='<em style=\"color:#c62828\">Preview failed.</em>';_prevFetching=false;});"
      output << "                return;"
      output << "              }"
      output << "            });"
      # Watch only style attributes, no childList — prevents innerHTML writes from re-triggering
      output << "          }).observe(jstBlock,{attributes:true,attributeFilter:['style'],subtree:true});"
      # Table/colour picker portal: move every dropdown div inside the toolbar
      # to document.body so modal overflow can never clip it.
      # jstoolbar keeps its reference to the same DOM node for show/hide.
      output << "          var jstEls=jstBlock.querySelector('.jstElements');"
      output << "          if(jstEls){"
      output << "            jstEls.querySelectorAll('span>div,span>table,a>div,a>table').forEach(function(picker){"
      output << "              var btn=picker.parentNode;"
      output << "              document.body.appendChild(picker);"
      output << "              picker.style.position='fixed';"
      output << "              picker.style.zIndex='2147483647';"
      output << "              new MutationObserver(function(){"
      output << "                var d=picker.style.display||window.getComputedStyle(picker).display;"
      output << "                if(d==='none') return;"
      output << "                var br=btn.getBoundingClientRect();"
      output << "                picker.style.top=(br.bottom+2)+'px';"
      output << "                picker.style.left=br.left+'px';"
      output << "              }).observe(picker,{attributes:true,attributeFilter:['style']});"
      output << "            });"
      output << "          }"
      output << "        },300);"
      output << "      }catch(e){ console.error('[PCU] toolbar init',e); }"
      output << "    },80);"
      # Restore saved values after field rebuild (used when Status changes)
      output << "    if(savedValues) setTimeout(function(){ pcuRestoreFieldValues(savedValues); },120);"
      # Wire Status select: when user changes status, reload fields for that status
      output << "    var statusSel=document.querySelector('#pcu-required-fields select[data-std-key=\"status_id\"]');"
      output << "    if(statusSel&&!statusSel._pcuStatusWired){"
      output << "      statusSel._pcuStatusWired=true;"
      output << "      statusSel.addEventListener('change',function(){"
      output << "        var sv=pcuSaveFieldValues();"
      output << "        sv['status_id']=this.value;"
      output << "        pcuLoadRequiredFields(#{issue.id},this.value,sv);"
      output << "      });"
      output << "    }"
      output << "  }).catch(function(err){ pcuShowStatus('Field load failed: '+err.message,'#fdecea','#c62828'); });"
      output << "}"

      # Submit: withChain=true → Save & Create Child Tracker; false → Save Tracker only
      output << "function pcuSubmit(parentId,withChain){"
      output << "  var tracker=document.getElementById('pcu-tracker-select').value;"
      output << "  var subject=document.getElementById('pcu-subject').value.trim();"
      output << "  if(!tracker){alert('Please select a child tracker type.');return;}"
      output << "  if(!subject){alert('Please enter a tracker subject.');return;}"
      output << "  var cfInputs=document.querySelectorAll('#pcu-required-fields .pcu-req-cf');"
      output << "  for(var i=0;i<cfInputs.length;i++){"
      output << "    if(cfInputs[i].disabled) continue;"
      output << "    if(cfInputs[i].dataset.required!=='1') continue;"
      output << "    if(!cfInputs[i].value||cfInputs[i].value.trim()===''){"
      output << "      var fn=cfInputs[i].dataset.fieldName||'A required field';"
      output << "      alert(fn+' cannot be blank.'); cfInputs[i].focus(); return;"
      output << "    }"
      output << "  }"
      output << "  var token=pcuCsrfToken();"
      output << "  if(!token){alert('CSRF token not found. Please reload.');return;}"
      output << "  var saveBtn=document.getElementById('pcu-btn-save');"
      output << "  var saveChildBtn=document.getElementById('pcu-btn-save-child');"
      output << "  saveBtn.disabled=true;"
      output << "  if(saveChildBtn) saveChildBtn.disabled=true;"
      output << "  var data=new FormData();"
      output << "  data.append('tracker_id',tracker);"
      output << "  data.append('subject',subject);"
      output << "  data.append('skip_chain',withChain?'0':'1');"
      output << "  var fileInput=document.getElementById('pcu-files');"
      output << "  if(fileInput&&fileInput.files.length>0){"
      output << "    for(var fi=0;fi<fileInput.files.length;fi++){"
      output << "      data.append('attachments['+fi+'][file]',fileInput.files[fi]);"
      output << "      data.append('attachments['+fi+'][filename]',fileInput.files[fi].name);"
      output << "    }"
      output << "  }"
      output << "  cfInputs.forEach(function(inp){"
      output << "    if(inp.disabled) return;"
      output << "    if(inp.dataset.stdKey&&inp.value){"
      output << "      data.append('std_fields['+inp.dataset.stdKey+']',inp.value);"
      output << "    } else if(inp.dataset.extKey){"
      output << "      if(inp.dataset.fieldFormat==='multiselect'&&inp._msWrap){"
      output << "        Object.keys(inp._msWrap._selected).forEach(function(val){"
      output << "          data.append('ext_fields['+inp.dataset.extKey+'][]',val);"
      output << "        });"
      output << "      } else if(inp.value){ data.append('ext_fields['+inp.dataset.extKey+']',inp.value); }"
      output << "    } else if(inp.dataset.cfId&&inp.value){"
      output << "      data.append('custom_field_values['+inp.dataset.cfId+']',inp.value);"
      output << "    }"
      output << "  });"
      output << "  fetch('/redmine_parent_to_child_update/child_issues/create/'+parentId,{"
      output << "    method:'POST',"
      output << "    headers:{'X-CSRF-Token':token,'X-Requested-With':'XMLHttpRequest','Accept':'application/json'},"
      output << "    body:data,credentials:'same-origin'"
      output << "  }).then(function(r){"
      output << "    return r.text().then(function(t){"
      output << "      if(!r.ok){try{var j=JSON.parse(t);throw new Error(j.error||t);}catch(e){throw new Error(t);}}"
      output << "      return JSON.parse(t);"
      output << "    });"
      output << "  }).then(function(json){"
      output << "    if(json.error){"
      output << "      pcuShowStatus(json.error,'#fdecea','#c62828');"
      output << "      saveBtn.disabled=false;"
      output << "      if(saveChildBtn) saveChildBtn.disabled=false;"
      output << "    } else if(json.redirect_to){"
      output << "      pcuShowStatus('Tracker created! Loading child creation...','#f0fdf4','#166534');"
      output << "      setTimeout(function(){"
      output << "        window.onbeforeunload=null;"
      output << "        if(window.jQuery) jQuery(window).off('beforeunload');"
      output << "        window.location.href=json.redirect_to;"
      output << "      },300);"
      output << "    } else {"
      output << "      pcuShowStatus('Tracker created successfully!','#f0fdf4','#166534');"
      output << "      setTimeout(function(){"
      output << "        window.onbeforeunload=null;"
      output << "        if(window.jQuery) jQuery(window).off('beforeunload');"
      output << "        window.location.reload();"
      output << "      },1200);"
      output << "    }"
      output << "  }).catch(function(err){"
      output << "    pcuShowStatus(err.message,'#fef2f2','#991b1b');"
      output << "    saveBtn.disabled=false;"
      output << "    if(saveChildBtn) saveChildBtn.disabled=false;"
      output << "  });"
      output << "}"

      output << "function pcuShowStatus(msg,bg,color){"
      output << "  var el=document.getElementById('pcu-status-msg');"
      output << "  el.style.display='block';el.style.background=bg;el.style.color=color;"
      output << "  el.style.borderColor=(color==='#166534'?'#bbf7d0':'#fecaca');"
      output << "  el.textContent=msg;"
      output << "}"

      # Inject ➕ Create Child button immediately before Redmine's + ADD subtask link
      output << "function pcuInjectSubtaskButton(issueId){"
      output << "  if(document.getElementById('pcu-add-btn-'+issueId)) return;"
      # Find Redmine's native subtask "+ ADD" anchor — href contains parent_issue_id=<id>
      output << "  var addLink=null;"
      output << "  var anchors=document.querySelectorAll('a');"
      output << "  for(var i=0;i<anchors.length;i++){"
      output << "    var h=anchors[i].href||'';"
      output << "    if((h.indexOf('parent_issue_id='+issueId)!==-1||"
      output << "        h.indexOf('parent_issue_id%5D='+issueId)!==-1||"
      output << "        h.indexOf('%5Bparent_issue_id%5D='+issueId)!==-1)&&"
      output << "       (anchors[i].className.indexOf('icon-add')!==-1||"
      output << "        /\\/issues\\/new/i.test(h))){"
      output << "      addLink=anchors[i]; break;"
      output << "    }"
      output << "  }"
      # Fallback: find icon-add anchor near a subtask table
      output << "  if(!addLink){"
      output << "    var tbl=document.getElementById('issue_tree')||document.querySelector('table.issues.subtasks');"
      output << "    if(tbl){"
      output << "      var lk=tbl.querySelector('a.icon-add')||tbl.previousElementSibling&&tbl.previousElementSibling.querySelector('a.icon-add');"
      output << "      if(lk) addLink=lk;"
      output << "    }"
      output << "  }"
      output << "  if(!addLink) return;"
      output << "  var btn=document.createElement('a');"
      output << "  btn.id='pcu-add-btn-'+issueId;"
      output << "  btn.href='#';"
      output << "  btn.className='pcu-subtask-btn';"
      output << "  btn.title='Create child issue via popup';"
      output << "  btn.innerHTML='CREATE CHILD';"
      output << "  btn.addEventListener('click',function(e){"
      output << "    e.preventDefault();"
      output << "    pcuCloseModal();"
      output << "    document.getElementById('pcu-child-modal').style.display='block';"
      output << "    pcuOnTrackerChange(issueId);"
      output << "  });"
      output << "  addLink.parentNode.insertBefore(btn,addLink);
      addLink.style.display='none';"
      # Make the parent container always visible (Redmine hides it until hover)
      output << "  var container=addLink.parentNode;"
      output << "  while(container&&container!==document.body){"
      output << "    var cs=window.getComputedStyle(container);"
      output << "    if(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'){"
      output << "      container.style.cssText+='display:block!important;visibility:visible!important;opacity:1!important;';"
      output << "    }"
      output << "    if(container.className&&(container.className.indexOf('contextual')!==-1||container.className.indexOf('links')!==-1)) {"
      output << "      container.style.cssText+='display:block!important;visibility:visible!important;opacity:1!important;';"
      output << "      break;"
      output << "    }"
      output << "    container=container.parentNode;"
      output << "  }"
      output << "}"

      # Move modal to <body> and auto-open for CR flow.
      # Use readyState check instead of just DOMContentLoaded: with Turbolinks/Hotwire
      # navigation DOMContentLoaded may already have fired when this inline script runs,
      # so the listener would never be called. Calling immediately when readyState is
      # already 'interactive' or 'complete' handles both cases.
      output << "(function(){"
      output << "  function pcuInitModal(){"
      output << "    var modal=document.getElementById('pcu-child-modal');"
      output << "    if(!modal) return;"
      output << "    if(modal.parentNode!==document.body) document.body.appendChild(modal);"
      if auto_open
        output << "    modal.style.display='block';"
        output << "    pcuOnTrackerChange(#{issue.id});"
      end
      output << "    pcuInjectSubtaskButton(#{issue.id});"
      output << "  }"
      output << "  if(document.readyState==='loading'){"
      output << "    document.addEventListener('DOMContentLoaded',pcuInitModal);"
      output << "  } else { pcuInitModal(); }"
      output << "})();"

      output << "</script>"
      output.html_safe
    end

  end
end
